#!/data/data/com.termux/files/usr/bin/bash
# modules/ia_3d.sh - Módulo de IA 3D (CORREGIDO y COMPLETO)

# Importar configuración
source "$(dirname "$0")/../config.sh"

# ===================== FUNCIONES IA 3D =====================
accion() {
    echo "Preparando modelo.scad vacío..."
    > "$HOME/modelo.scad"
    ${EDITOR:-nano} "$HOME/modelo.scad"
    echo "Ejecutando modelo.scad con OpenSCAD..."
    proot-distro login debian -- /usr/bin/openscad -o "$DL/modelo.stl" "$HOME/modelo.scad"
    if [ -f "$DL/modelo.stl" ]; then
        echo "STL actualizado en Descargas."
    else
        echo "No se encontró modelo.stl tras ejecutar OpenSCAD."
    fi
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

freecad_run() {
    echo "Preparando modelo.py..."
    touch "$HOME/modelo.py"
    ${EDITOR:-nano} "$HOME/modelo.py"
    echo "Ejecutando modelo.py con FreeCAD..."
    proot-distro login debian -- /usr/bin/freecadcmd "$HOME/modelo.py"
    if [ -f "$DL/modelo.stl" ]; then
        echo "STL actualizado en Descargas."
    else
        echo "No se encontró modelo.stl tras ejecutar FreeCAD."
    fi
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

ver() {
    if [ -f "$DL/modelo.stl" ]; then
        termux-open "$DL/modelo.stl"
    else
        echo "No existe $DL/modelo.stl"
    fi
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

subir_stl() {
    if [ ! -f "$DL/modelo.stl" ]; then
        echo "No existe modelo.stl para subir."
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return
    fi
    read -rp "Nombre del proyecto: " PROYECTO
    fecha=$(date +%Y%m%d_%H%M%S)
    STL_FILE="$DL/modelo.stl"
    CODE_FILE="$HOME/modelo.scad"
    STL_GH="${PROYECTO}/modelo_${fecha}.stl"
    CODE_GH="${PROYECTO}/modelo_${fecha}.scad"
    base64_stl=$(base64 -w 0 "$STL_FILE")
    tmpjson=$(mktemp)
    cat > "$tmpjson" <<EOF
{
  "message": "Subida STL $STL_GH",
  "content": "$base64_stl"
}
EOF
    curl -s -X PUT "https://api.github.com/repos/$OWNER/$REPO/contents/$STL_GH" \
        -H "Authorization: token $TOKEN" \
        -H "Content-Type: application/json" \
        -d @"$tmpjson"
    rm "$tmpjson"
    if [ -f "$CODE_FILE" ]; then
        base64_code=$(base64 -w 0 "$CODE_FILE")
        tmpjson=$(mktemp)
        cat > "$tmpjson" <<EOF
{
  "message": "Subida código $CODE_GH",
  "content": "$base64_code"
}
EOF
        curl -s -X PUT "https://api.github.com/repos/$OWNER/$REPO/contents/$CODE_GH" \
            -H "Authorization: token $TOKEN" \
            -H "Content-Type: application/json" \
            -d @"$tmpjson"
        rm "$tmpjson"
    fi
    echo "Subida completada."
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

# Función para refinar el modelo OpenSCAD (CORREGIDA)
refine_openscad_model() {
    clear
    echo "===== Refinar Modelo OpenSCAD ====="
    echo "Describe qué cambios quieres hacer en el modelo actual."
    echo "Por ejemplo: 'Haz el agujero central 2mm más grande', 'Añade un bisel en los bordes', 'Hazlo un 10% más delgado'."
    read -rp "Instrucciones de refinamiento: " feedback
    if [ -z "$feedback" ]; then
        echo "No se proporcionó feedback. Volviendo al menú."
        return
    fi
    # Leer el código actual
    current_code=$(cat "$HOME/modelo.scad")
    echo "Refinando el modelo..."
    REFINE_PROMPT="Este es el código OpenSCAD actual:
$current_code
Por favor, modifícalo según la siguiente instrucción:
$feedback
Solo devuelve el código OpenSCAD modificado, sin comentarios ni explicaciones adicionales."
    tmp_response=$(mktemp)
    curl -s -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$GEMINI_KEY" \
        -H 'Content-Type: application/json' \
        -d "{\"contents\":[{\"parts\":[{\"text\":\"$REFINE_PROMPT\"}]}]}" > "$tmp_response"
    refined_code=$(jq -r '.candidates[0].content.parts[0].text' "$tmp_response")
    if [ -z "$refined_code" ] || [ "$refined_code" == "null" ]; then
        echo "ERROR: La IA no pudo generar un código refinado válido."
        cat "$tmp_response"
        rm "$tmp_response"
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return
    fi
    # --- CORRECCIÓN: LIMPIEZA DEL CÓDIGO ---
    # Eliminar bloques de código Markdown (```openscad, ```python, ```)
    cleaned_code=$(echo "$refined_code" | sed -e '/^```\(openscad\|python\|json\)\?$/d' -e '/^```$/d')
    if [ -z "$cleaned_code" ]; then
        echo "ERROR: La respuesta de la IA está vacía después de la limpieza."
        echo "La respuesta original de la IA fue:"
        echo "$refined_code"
        rm "$tmp_response"
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return
    fi
    # --- FIN DE LA LIMPIEZA ---
    echo "$cleaned_code" > "$HOME/modelo.scad"
    rm "$tmp_response"
    echo "Código refinado guardado en $HOME/modelo.scad"
    echo "Compilando el archivo refinado..."
    proot-distro login debian -- /usr/bin/openscad -o "$DL/modelo.stl" "$HOME/modelo.scad"
    if [ -f "$DL/modelo.stl" ]; then
        echo "Nuevo STL generado en Descargas."
    else
        echo "No se encontró modelo.stl tras la compilación."
    fi
}

# Función para generar código OpenSCAD con IA (versión NUCLEAR y CORREGIDA)
generate_openscad_code() {
    clear
    echo "===== Generar código OpenSCAD con IA (Gemini) ====="
    echo "1) Escribir prompt personalizado"
    echo "2) Elegir una plantilla (EDITAR MANUALMENTE)"
    echo "0) Volver"
    echo "--------------------------"
    read -rp "Elige opción: " choice
    case $choice in
        1)
            echo "Escribe el prompt para generar el modelo. Guarda y sal del editor para continuar."
            tmp_prompt=$(mktemp)
            ${EDITOR:-nano} "$tmp_prompt"
            prompt_content=$(cat "$tmp_prompt")
            rm "$tmp_prompt"
            ;;
        2)
            # Listar plantillas
            templates=("$TEMPLATES_DIR"/*.scad.prompt)
            if [ ${#templates[@]} -eq 0 ] || [ ! -f "${templates[0]}" ]; then
                echo "No hay plantillas disponibles."
                read -n1 -s -r -p "Pulsa cualquier tecla..."
                return
            fi
            echo "Elige una plantilla:"
            # Contador para numerar las plantillas válidas
            valid_index=1
            # Array para mapear el índice del menú al índice real del array
            declare -a menu_to_template_map
            for i in "${!templates[@]}"; do
                template_name=$(basename "${templates[$i]}" .scad.prompt)
                # Mostrar nombres amigables para TODAS las plantillas
                case "$template_name" in
                    "caja_basica_openscad") display_name="Caja Básica" ;;
                    "engranaje_openscad") display_name="Engranaje" ;;
                    "caja_bisagras_magnetica_openscad") display_name="Caja con Bisagras y Magnético" ;;
                    "soporte_telefono_openscad") display_name="Soporte para Teléfono" ;;
                    "engranaje_helicoidal_openscad") display_name="Engranaje Helicoidal" ;;
                    *) 
                        # Para cualquier otra plantilla, mostrar un nombre genérico
                        display_name="Plantilla: $(echo "$template_name" | sed 's/_/ /g')"
                        ;;
                esac
                echo "$valid_index) $display_name"
                # Mapeamos el índice del menú (1,2,3...) al índice real del array
                menu_to_template_map[$valid_index]=$i
                ((valid_index++))
            done
            echo "0) Volver"
            read -rp "Opción: " template_choice
            if [ "$template_choice" -eq 0 ]; then
                return
            fi
            # Verificar que la opción elegida es válida
            if [ -z "${menu_to_template_map[$template_choice]}" ]; then
                echo "Opción de plantilla no válida."
                read -n1 -s -r -p "Pulsa cualquier tecla..."
                return
            fi
            # Obtener el índice real del array de plantillas
            real_index=${menu_to_template_map[$template_choice]}
            selected_template="${templates[$real_index]}"
            # Copiar la plantilla a un archivo temporal para que el usuario la edite
            tmp_prompt=$(mktemp)
            cp "$selected_template" "$tmp_prompt"
            echo "Edita el prompt a continuación. Reemplaza los placeholders [ancho], [profundidad], etc. con los valores deseados."
            echo "Guarda y sal del editor para continuar."
            ${EDITOR:-nano} "$tmp_prompt"
            prompt_content=$(cat "$tmp_prompt")
            rm "$tmp_prompt"
            ;;
        0)
            return
            ;;
        *)
            echo "Opción inválida."
            read -n1 -s -r -p "Pulsa cualquier tecla..."
            return
            ;;
    esac
    if [ -z "$prompt_content" ]; then
        echo "No se ha introducido ningún prompt. Volviendo al menú."
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return
    fi
    echo "Generando código OpenSCAD..."
    FULL_PROMPT="Genera un script de OpenSCAD para la siguiente descripción. No incluyas texto extra, explicaciones ni bloques de código markdown. Solo devuelve el código.
$prompt_content"
    tmp_response=$(mktemp)
    curl -s -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$GEMINI_KEY" \
        -H 'Content-Type: application/json' \
        -d "{\"contents\":[{\"parts\":[{\"text\":\"$FULL_PROMPT\"}]}]}" > "$tmp_response"
    code_content=$(jq -r '.candidates[0].content.parts[0].text' "$tmp_response")
    if [ -z "$code_content" ] || [ "$code_content" == "null" ]; then
        echo "ERROR: La IA no pudo generar un código válido."
        echo "El prompt de la IA fue: "
        echo "$FULL_PROMPT"
        echo "La respuesta de la IA fue:"
        cat "$tmp_response"
        rm "$tmp_response"
        read -n1 -s -r -p "Revisa tu prompt o inténtalo de nuevo. Pulsa cualquier tecla..."
        return
    fi
    # --- CORRECCIÓN: LIMPIEZA DEL CÓDIGO ---
    # Eliminar bloques de código Markdown (```openscad, ```python, ```)
    cleaned_code=$(echo "$code_content" | sed -e '/^```\(openscad\|python\|json\)\?$/d' -e '/^```$/d')
    if [ -z "$cleaned_code" ]; then
        echo "ERROR: La respuesta de la IA está vacía después de la limpieza."
        echo "La respuesta original de la IA fue:"
        echo "$code_content"
        rm "$tmp_response"
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return
    fi
    # --- FIN DE LA LIMPIEZA ---
    echo "$cleaned_code" > "$HOME/modelo.scad"
    rm "$tmp_response"
    echo "Código generado y guardado en $HOME/modelo.scad"
    echo "Compilando el archivo para generar el STL..."
    proot-distro login debian -- /usr/bin/openscad -o "$DL/modelo.stl" "$HOME/modelo.scad"
    if [ -f "$DL/modelo.stl" ]; then
        echo "STL actualizado en Descargas."
        # Preguntar si quiere refinar el modelo
        read -rp "¿Quieres refinar este modelo? (s/n): " refine
        if [[ "$refine" == "s" || "$refine" == "S" ]]; then
            refine_openscad_model
        fi
    else
        echo "No se encontró modelo.stl tras la compilación."
    fi
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

# Función para generar código FreeCAD con IA (versión NUCLEAR y CORREGIDA)
generate_freecad_code() {
    clear
    echo "===== Generar código FreeCAD (Python) con IA ====="
    echo "1) Escribir prompt personalizado"
    echo "2) Elegir una plantilla (EDITAR MANUALMENTE)"
    echo "0) Volver"
    echo "--------------------------"
    read -rp "Elige opción: " choice
    case $choice in
        1)
            echo "Escribe el prompt para generar el script. Guarda y sal del editor para continuar."
            tmp_prompt=$(mktemp)
            ${EDITOR:-nano} "$tmp_prompt"
            prompt_content=$(cat "$tmp_prompt")
            rm "$tmp_prompt"
            ;;
        2)
            # Listar plantillas
            templates=("$TEMPLATES_DIR"/*.py.prompt)
            if [ ${#templates[@]} -eq 0 ] || [ ! -f "${templates[0]}" ]; then
                echo "No hay plantillas disponibles."
                read -n1 -s -r -p "Pulsa cualquier tecla..."
                return
            fi
            echo "Elige una plantilla:"
            # Contador para numerar las plantillas válidas
            valid_index=1
            # Array para mapear el índice del menú al índice real del array
            declare -a menu_to_template_map
            for i in "${!templates[@]}"; do
                template_name=$(basename "${templates[$i]}" .py.prompt)
                # Mostrar nombres amigables para TODAS las plantillas
                case "$template_name" in
                    "caja_basica_freecad") display_name="Caja Básica" ;;
                    "soporte_L_freecad") display_name="Soporte en L" ;;
                    "tuerca_perno_freecad") display_name="Tuerca y Perno" ;;
                    "cuadro_bici_freecad") display_name="Marco de Bicicleta" ;;
                    "caja_cambios_freecad") display_name="Caja de Cambios 2 Vel." ;;
                    *) 
                        # Para cualquier otra plantilla, mostrar un nombre genérico
                        display_name="Plantilla: $(echo "$template_name" | sed 's/_/ /g')"
                        ;;
                esac
                echo "$valid_index) $display_name"
                # Mapeamos el índice del menú (1,2,3...) al índice real del array
                menu_to_template_map[$valid_index]=$i
                ((valid_index++))
            done
            echo "0) Volver"
            read -rp "Opción: " template_choice
            if [ "$template_choice" -eq 0 ]; then
                return
            fi
            # Verificar que la opción elegida es válida
            if [ -z "${menu_to_template_map[$template_choice]}" ]; then
                echo "Opción de plantilla no válida."
                read -n1 -s -r -p "Pulsa cualquier tecla..."
                return
            fi
            # Obtener el índice real del array de plantillas
            real_index=${menu_to_template_map[$template_choice]}
            selected_template="${templates[$real_index]}"
            # Copiar la plantilla a un archivo temporal para que el usuario la edite
            tmp_prompt=$(mktemp)
            cp "$selected_template" "$tmp_prompt"
            echo "Edita el prompt a continuación. Reemplaza los placeholders [ancho], [profundidad], etc. con los valores deseados."
            echo "Guarda y sal del editor para continuar."
            ${EDITOR:-nano} "$tmp_prompt"
            prompt_content=$(cat "$tmp_prompt")
            rm "$tmp_prompt"
            ;;
        0)
            return
            ;;
        *)
            echo "Opción inválida."
            read -n1 -s -r -p "Pulsa cualquier tecla..."
            return
            ;;
    esac
    if [ -z "$prompt_content" ]; then
        echo "No se ha introducido ningún prompt. Volviendo al menú."
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return
    fi
    echo "Generando código FreeCAD (Python)..."
    FULL_PROMPT="Genera un script de Python completo y válido para FreeCAD basado en la siguiente descripción. El script debe ser totalmente funcional y guardar el resultado como un archivo STL con la ruta completa '$DL/modelo.stl'. Utiliza solo operaciones booleanas y formas básicas (cajas, cilindros) para construir geometrías complejas. Asegúrate de que todas las operaciones booleanas sean entre dos formas sólidas para evitar el error 'Part.Compound'. No incluyas texto extra, explicaciones, JSON ni bloques de código markdown. Solo devuelve el código.
$prompt_content"
    tmp_response=$(mktemp)
    curl -s -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$GEMINI_KEY" \
        -H 'Content-Type: application/json' \
        -d "{\"contents\":[{\"parts\":[{\"text\":\"$FULL_PROMPT\"}]}]}" > "$tmp_response"
    code_content=$(jq -r '.candidates[0].content.parts[0].text' "$tmp_response")
    if [ -z "$code_content" ] || [ "$code_content" == "null" ]; then
        echo "ERROR: La IA no pudo generar un código válido."
        echo "El prompt de la IA fue: "
        echo "$FULL_PROMPT"
        echo "La respuesta de la IA fue:"
        cat "$tmp_response"
        rm "$tmp_response"
        read -n1 -s -r -p "Revisa tu prompt o inténtalo de nuevo. Pulsa cualquier tecla..."
        return
    fi
    # --- LIMPIEZA DEL CÓDIGO ---
    # Eliminar bloques de código Markdown (```python, ```json, ```)
    cleaned_code=$(echo "$code_content" | sed -e '/^```\(python\|json\)\?$/d' -e '/^```$/d')
    if [ -z "$cleaned_code" ]; then
        echo "ERROR: La respuesta de la IA está vacía después de la limpieza."
        echo "La respuesta original de la IA fue:"
        echo "$code_content"
        rm "$tmp_response"
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return
    fi
    # --- FIN DE LA LIMPIEZA ---
    echo "$cleaned_code" > "$HOME/modelo.py"
    rm "$tmp_response"
    echo "Código generado y guardado en $HOME/modelo.py"
    echo "Compilando el script para generar el STL..."
    proot-distro login debian -- /usr/bin/freecadcmd "$HOME/modelo.py"
    if [ -f "$DL/modelo.stl" ]; then
        echo "STL actualizado en Descargas."
    else
        echo "No se encontró modelo.stl tras la compilación."
    fi
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

# --- MENÚ IA 3D (CORREGIDO) ---
while :; do
    clear
    echo "===== IA 3D ====="
    echo "1) OpenSCAD"
    echo "2) FreeCAD"
    echo "3) Ver STL con app predeterminada"
    echo "4) Subir STL a GitHub"
    echo "5) Generar OpenSCAD con IA"
    echo "6) Generar FreeCAD con IA"
    echo "0) Volver"
    echo "=================="
    read -rp "Elige opción: " subopt
    case $subopt in
        1) accion ;;
        2) freecad_run ;;
        3) ver ;;
        4) subir_stl ;;
        5) generate_openscad_code ;;
        6) generate_freecad_code ;;
        0) break ;;
        *) echo "Opción inválida"; sleep 1 ;;
    esac
done
