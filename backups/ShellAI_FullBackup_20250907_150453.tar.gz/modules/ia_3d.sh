#!/data/data/com.termux/files/usr/bin/bash
# modules/ia_3d.sh - Módulo de IA 3D

# Importar configuración
source "$(dirname "$0")/../config.sh"

# ... (Tus funciones accion, freecad_run, ver, subir_stl, refine_openscad_model, etc.) ...

# Función para generar código OpenSCAD con IA (versión CORREGIDA para mostrar todas las plantillas)
generate_openscad_code() {
    clear
    echo "===== Generar código OpenSCAD con IA (Gemini) ====="
    echo "1) Escribir prompt personalizado"
    echo "2) Elegir una plantilla (EDITAR MANUALMENTE)"
    echo "0) Volver"
    echo "--------------------------"
    read -rp "Elige opción: " choice
    case $choice in
        1)
            echo "Escribe el prompt para generar el modelo. Guarda y sal del editor para continuar."
            tmp_prompt=$(mktemp)
            ${EDITOR:-nano} "$tmp_prompt"
            prompt_content=$(cat "$tmp_prompt")
            rm "$tmp_prompt"
            ;;
        2)
            templates=("$TEMPLATES_DIR"/*.scad.prompt)
            if [ ${#templates[@]} -eq 0 ] || [ ! -f "${templates[0]}" ]; then
                echo "No hay plantillas disponibles."
                read -n1 -s -r -p "Pulsa cualquier tecla..."
                return
            fi
            echo "Elige una plantilla:"
            valid_index=1
            declare -a menu_to_template_map
            for i in "${!templates[@]}"; do
                template_name=$(basename "${templates[$i]}" .scad.prompt)
                case "$template_name" in
                    "caja_basica_openscad") display_name="Caja Básica" ;;
                    "engranaje_openscad") display_name="Engranaje" ;;
                    "caja_bisagras_magnetica_openscad") display_name="Caja con Bisagras y Magnético" ;;
                    *) display_name="Plantilla: $(echo "$template_name" | sed 's/_/ /g')" ;;
                esac
                echo "$valid_index) $display_name"
                menu_to_template_map[$valid_index]=$i
                ((valid_index++))
            done
            echo "0) Volver"
            read -rp "Opción: " template_choice
            if [ "$template_choice" -eq 0 ]; then
                return
            fi
            if [ -z "${menu_to_template_map[$template_choice]}" ]; then
                echo "Opción de plantilla no válida."
                read -n1 -s -r -p "Pulsa cualquier tecla..."
                return
            fi
            real_index=${menu_to_template_map[$template_choice]}
            selected_template="${templates[$real_index]}"
            tmp_prompt=$(mktemp)
            cp "$selected_template" "$tmp_prompt"
            echo "Edita el prompt a continuación. Reemplaza los placeholders [ancho], [profundidad], etc. con los valores deseados."
            echo "Guarda y sal del editor para continuar."
            ${EDITOR:-nano} "$tmp_prompt"
            prompt_content=$(cat "$tmp_prompt")
            rm "$tmp_prompt"
            ;;
        0)
            return
            ;;
        *)
            echo "Opción inválida."
            read -n1 -s -r -p "Pulsa cualquier tecla..."
            return
            ;;
    esac
    # ... (resto de la lógica para generar el código) ...
}

# --- MENÚ IA 3D ---
while :; do
    clear
    echo "===== IA 3D ====="
    echo "1) OpenSCAD"
    echo "2) FreeCAD"
    echo "3) Ver STL con app predeterminada"
    echo "4) Subir STL a GitHub"
    echo "5) Generar OpenSCAD con IA"
    echo "6) Generar FreeCAD con IA"
    echo "0) Volver"
    echo "=================="
    read -rp "Elige opción: " subopt
    case $subopt in
        1) accion ;;
        2) freecad_run ;;
        3) ver ;;
        4) subir_stl ;;
        5) generate_openscad_code ;;
        6) generate_freecad_code ;;
        0) break ;;
        *) echo "Opción inválida"; sleep 1 ;;
    esac
done
