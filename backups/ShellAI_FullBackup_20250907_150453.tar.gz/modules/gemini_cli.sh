#!/data/data/com.termux/files/usr/bin/bash
# modules/gemini_cli.sh - Módulo de chat con Gemini

# Importar configuración
source "$(dirname "$0")/../config.sh"

gemini_cli_chat() {
    clear
    echo "===== Gemini CLI Chat ====="
    echo "Escribe tu consulta. Escribe 'salir' para volver al menú principal."
    echo "--------------------------"
    while true; do
        read -rp "Tú: " query
        if [ "$query" == "salir" ]; then
            break
        fi
        if [ -z "$query" ]; then
            echo "No has introducido ninguna consulta."
            continue
        fi
        echo "Gemini: "
        response=$(curl -s -X POST "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$GEMINI_KEY" \
        -H 'Content-Type: application/json' \
        -d "{\"contents\":[{\"parts\":[{\"text\":\"$query\"}]}]}" | jq -r '.candidates[0].content.parts[0].text')
        echo "$response"
        echo
    done
}

gemini_cli_chat
