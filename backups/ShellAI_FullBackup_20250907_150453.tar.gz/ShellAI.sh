#!/data/data/com.termux/files/usr/bin/bash
# ShellAI.sh - Script principal (lanzador/orquestador)

# ===================== CONFIGURACIÓN =====================
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# --- Función de Inicialización Automática (CORREGIDA) ---
initialize_environment() {
    # Verificar si el entorno YA está instalado
    if command -v proot-distro &> /dev/null && \
       proot-distro login debian -- command -v openscad &> /dev/null && \
       proot-distro login debian -- command -v freecadcmd &> /dev/null && \
       [ -f "$HOME/.config/storage_done" ]; then
        echo -e "\033[0;32m[✓] Entorno ya configurado. Saltando instalación.\033[0m"
        return 0
    fi

    echo -e "\033[0;32m[*] Iniciando instalación de ShellAI...\033[0m"
    echo "=============================================="

    # Paso 1: Instalar dependencias básicas de Termux
    echo "🔹 Paso 1/5: Instalando dependencias de Termux..."
    pkg update -y >/dev/null 2>&1
    pkg install -y proot-distro git curl wget nano vim jq tar gzip openssl termux-api >/dev/null 2>&1
    echo "✅ Paso 1/5 completado."

    # Paso 2: Instalar y configurar Debian
    echo "🔹 Paso 2/5: Instalando Debian..."
    if ! proot-distro list | grep -q '^debian'; then
        proot-distro install debian >/dev/null 2>&1
    fi
    echo "✅ Paso 2/5 completado."

    # Paso 3: Instalar herramientas 3D y de red en Debian
    echo "🔹 Paso 3/5: Instalando OpenSCAD, FreeCAD y herramientas de red..."
    proot-distro login debian -- bash -c "
        apt update >/dev/null 2>&1 &&
        apt upgrade -y >/dev/null 2>&1 &&
        apt install -y --no-install-recommends openscad freecad freecad-common freecad-python3 \\
                      iproute2 net-tools traceroute mtr whois dnsutils tcpdump nmap \\
                      python3 python3-pip" >/dev/null 2>&1
    echo "✅ Paso 3/5 completado."

    # Paso 4: Solicitar acceso al almacenamiento
    echo "🔹 Paso 4/5: Configurando acceso al almacenamiento..."
    STORAGE_FLAG="$HOME/.config/storage_done"
    if [ ! -f "$STORAGE_FLAG" ]; then
        termux-setup-storage
        mkdir -p "$HOME/.config"
        touch "$STORAGE_FLAG"
    fi
    echo "✅ Paso 4/5 completado."

    # Paso 5: Crear directorios del proyecto
    echo "🔹 Paso 5/5: Creando estructura de directorios..."
    mkdir -p "$HOME/docs"
    mkdir -p "$HOME/.shortcuts/restore_temp"
    mkdir -p "$HOME/docs/templates"
    echo "✅ Paso 5/5 completado."

    echo -e "\n\033[0;32m[✓] ¡Entorno configurado correctamente!\033[0m"
}

# Ejecutar inicialización
initialize_environment

# ===================== MENÚ PRINCIPAL =====================
while :; do
    clear
    echo "===== SHELLAI.SH ====="
    echo "1) IA 3D"
    echo "2) Usar Gemini CLI"
    echo "3) Backup COMPLETO del Proyecto a GitHub"
    echo "4) Iniciar shell Debian"
    echo "5) Utilidades Networking"
    echo "6) Salir"
    echo "=========================="
    read -rp "Elige opción: " opt
    case $opt in
        1) "$SCRIPT_DIR/modules/ia_3d.sh" ;;
        2) "$SCRIPT_DIR/modules/gemini_cli.sh" ;;
        3) "$SCRIPT_DIR/modules/upload_script.sh" ;;
        4) "$SCRIPT_DIR/modules/debian_shell.sh" ;;
        5) "$SCRIPT_DIR/modules/networking.sh" ;;
        6) exit ;;
        *) echo "Opción inválida"; sleep 1 ;;
    esac
done
