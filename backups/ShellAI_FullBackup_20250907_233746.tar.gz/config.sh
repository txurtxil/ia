#!/data/data/com.termux/files/usr/bin/bash
# config.sh - Configuración global y funciones de inicialización

# --- Variables de Configuración ---
export HOME_DOCS="$HOME/docs"
export DL="$HOME/storage/downloads"
export SHORTCUTS_DIR="$HOME/.shortcuts"
export PROOT_DIR="/data/data/com.termux/files/usr/var/lib/proot-distro/installed-rootfs/debian"
export DOCS_DIR="$HOME/storage/shared/Documents"
export BACKUP_FILE="$DOCS_DIR/backup_latest.tar.gz"
export ENCRYPTED_BACKUP="$DOCS_DIR/backup_latest.enc"
export CONF_FILE="$HOME/.config/shell_conf"
export TEMPLATES_DIR="$HOME_DOCS/templates"
export OWNER="txurtxil"
export REPO="ia"

# --- Funciones de Inicialización ---
initialize_directories() {
    mkdir -p "$SHORTCUTS_DIR/restore_temp"
    mkdir -p "$HOME/.config"
    mkdir -p "$HOME_DOCS"
    mkdir -p "$TEMPLATES_DIR"
}

request_storage_access() {
    STORAGE_FLAG="$HOME/.config/storage_done"
    if [ ! -f "$STORAGE_FLAG" ]; then
        echo "[*] Habilitando acceso al almacenamiento compartido..."
        termux-setup-storage
        touch "$STORAGE_FLAG"
    fi
}

load_or_prompt_credentials() {
    if [ -f "$CONF_FILE" ]; then
        source "$CONF_FILE"
    fi

    if [ -z "$TOKEN" ] || [ -z "$PASS" ] || [ -z "$GEMINI_KEY" ]; then
        echo "¡Configuración inicial necesaria!"
        [ -z "$TOKEN" ] && read -rp "Introduce TOKEN de GitHub: " TOKEN
        [ -z "$PASS" ] && read -srp "Introduce contraseña de backup: " PASS
        [ -z "$GEMINI_KEY" ] && read -srp "Introduce tu clave de la API de Gemini: " GEMINI_KEY
        echo
        echo "TOKEN=\"$TOKEN\"" > "$CONF_FILE"
        echo "PASS=\"$PASS\"" >> "$CONF_FILE"
        echo "GEMINI_KEY=\"$GEMINI_KEY\"" >> "$CONF_FILE"
        chmod 600 "$CONF_FILE"
        echo "Configuración guardada en $CONF_FILE."
        read -n1 -s -r -p "Pulsa cualquier tecla para continuar..."
    fi
    export TOKEN PASS GEMINI_KEY
}

# --- PLANTILLAS AVANZADAS ---
create_default_templates() {
    # ========== PLANTILLAS OPENSCAD ==========

    # Plantilla: Caja Básica
    cat > "$TEMPLATES_DIR/caja_basica_openscad.scad.prompt" << 'EOF'
Crea una caja rectangular en OpenSCAD con las siguientes dimensiones:
- Ancho: [ancho] mm.
- Profundidad: [profundidad] mm.
- Altura: [altura] mm.
- Grosor de las paredes: [grosor] mm.
- La tapa debe ser separable y encajar perfectamente.
- Solo devuelve el código OpenSCAD, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Engranaje
    cat > "$TEMPLATES_DIR/engranaje_openscad.scad.prompt" << 'EOF'
Crea un engranaje de [numero_dientes] dientes en OpenSCAD.
- Diámetro exterior: [diametro_exterior] mm.
- Grosor del engranaje: [grosor] mm.
- Diámetro del agujero central: [diametro_agujero] mm.
- Asegúrate de que el engranaje sea simétrico y que los dientes estén correctamente espaciados.
- Solo devuelve el código OpenSCAD, sin comentarios ni explicaciones adicionales.
EOF

    # ========== PLANTILLAS FREECAD ==========

    # Plantilla: Soporte en L
    cat > "$TEMPLATES_DIR/soporte_L_freecad.py.prompt" << 'EOF'
Crea un soporte en forma de L en FreeCAD usando Python.
- La base debe medir [largo_base] mm de largo y [ancho_base] mm de ancho.
- La altura vertical debe ser [altura] mm.
- El grosor del material debe ser [grosor] mm.
- El soporte debe tener agujeros de [diametro_agujeros] mm de diámetro en las esquinas para tornillos.
- Guarda el resultado como un archivo STL en la ruta: /data/data/com.termux/files/home/storage/downloads/modelo.stl
- Solo devuelve el código Python, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Caja Básica
    cat > "$TEMPLATES_DIR/caja_basica_freecad.py.prompt" << 'EOF'
Crea una caja rectangular sólida en FreeCAD usando Python.
- Ancho: [ancho] mm.
- Profundidad: [profundidad] mm.
- Altura: [altura] mm.
- La caja debe ser un único objeto sólido.
- Guarda el resultado como un archivo STL en la ruta: /data/data/com.termux/files/home/storage/downloads/modelo.stl
- Solo devuelve el código Python, sin comentarios ni explicaciones adicionales.
EOF
}

# --- Inicialización Automática ---
initialize_directories
request_storage_access
load_or_prompt_credentials
create_default_templates
