#!/data/data/com.termux/files/usr/bin/bash
# modules/upload_script.sh - Módulo para subir TODO el proyecto a GitHub

# Importar configuración
source "$(dirname "$0")/../config.sh"

# --- NUEVA FUNCIÓN: Subir TODO el proyecto ---
backup_full_project_to_github() {
    clear
    echo "===== Creando Backup Completo del Proyecto ====="

    # 1. Definir rutas
    PROJECT_ROOT="$(dirname "$SCRIPT_DIR")" # <-- Esto apunta a la carpeta padre de 'modules'
    BACKUP_NAME="ShellAI_FullBackup_$(date +%Y%m%d_%H%M%S).tar.gz"
    LOCAL_BACKUP_PATH="$DOCS_DIR/$BACKUP_NAME"

    # 2. Crear el archivo .tar.gz
    echo "Empaquetando archivos..."
    cd "$PROJECT_ROOT" || { echo "Error: No se puede acceder a $PROJECT_ROOT"; read -n1 -s -r -p "Pulsa cualquier tecla..."; return 1; }

    # Creamos el tar.gz excluyendo el archivo de configuración con las claves
    tar --exclude="$CONF_FILE" \
        --exclude="*.enc" \
        --exclude="*.tar.gz" \
        -czf "$LOCAL_BACKUP_PATH" \
        "ShellAI.sh" \
        "config.sh" \
        "modules/"

    if [ ! -f "$LOCAL_BACKUP_PATH" ]; then
        echo "❌ Error: No se pudo crear el archivo de backup."
        read -n1 -s -r -p "Pulsa cualquier tecla..."
        return 1
    fi

    echo "✅ Backup creado localmente: $LOCAL_BACKUP_PATH"

    # 3. Codificar el archivo en base64 para la API de GitHub
    echo "Preparando subida a GitHub..."
    base64_content=$(base64 -w 0 "$LOCAL_BACKUP_PATH")

    # 4. Crear el JSON para la API
    tmpjson=$(mktemp)
    cat > "$tmpjson" <<EOF
{
  "message": "Backup completo del proyecto ShellAI: $BACKUP_NAME",
  "content": "$base64_content"
}
EOF

    # 5. Subir el archivo a GitHub
    echo "Subiendo a GitHub..."
    response=$(curl -s -X PUT "https://api.github.com/repos/$OWNER/$REPO/contents/backups/$BACKUP_NAME" \
        -H "Authorization: token $TOKEN" \
        -H "Content-Type: application/json" \
        -d @"$tmpjson")

    # 6. Limpiar archivos temporales
    rm "$tmpjson"

    # 7. Verificar el resultado
    if echo "$response" | grep -q '"sha"'; then
        echo "✅ ¡Backup completo subido correctamente a GitHub!"
        echo "   Ruta en el repo: backups/$BACKUP_NAME"
        # Opcional: Eliminar el backup local para ahorrar espacio
        # rm "$LOCAL_BACKUP_PATH"
    else
        echo "❌ Error al subir el backup a GitHub."
        echo "Respuesta de GitHub:"
        echo "$response" | jq . 2>/dev/null || echo "$response"
    fi

    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

# Ejecutar la nueva función
backup_full_project_to_github
