#!/data/data/com.termux/files/usr/bin/bash
# ShellAI.sh - Script principal (lanzador/orquestador)

# ===================== CONFIGURACIÓN =====================
# Ruta base donde se encuentran todos los scripts del proyecto.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ===================== MENÚ PRINCIPAL =====================
while :; do
    clear
    echo "===== SHELLAI.SH ====="
    echo "1) IA 3D"
    echo "2) Instalar-Restaurar entorno"
    echo "3) Usar Gemini CLI"
    echo "4) Backup COMPLETO del Proyecto a GitHub"
    echo "5) Iniciar shell Debian"
    echo "6) Utilidades Networking"
    echo "7) Salir"
    echo "=========================="
    read -rp "Elige opción: " opt
    case $opt in
        1) "$SCRIPT_DIR/modules/ia_3d.sh" ;;
        2) "$SCRIPT_DIR/modules/entorno.sh" ;;
        3) "$SCRIPT_DIR/modules/gemini_cli.sh" ;;
        4) "$SCRIPT_DIR/modules/upload_script.sh" ;;
        5) "$SCRIPT_DIR/modules/debian_shell.sh" ;;
        6) "$SCRIPT_DIR/modules/networking.sh" ;; # <-- ¡CORRECCIÓN AQUÍ!
        7) exit ;;
        *) echo "Opción inválida"; sleep 1 ;;
    esac
done
