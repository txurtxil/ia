#!/data/data/com.termux/files/usr/bin/bash
# ShellAI.sh - Script principal con soporte para PrusaSlicer en BambuLab A1 Mini

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ===================== INICIALIZACIÓN =====================
initialize_environment() {
    if command -v proot-distro &> /dev/null && \
       proot-distro login debian -- command -v openscad &> /dev/null && \
       proot-distro login debian -- command -v freecadcmd &> /dev/null && \
       [ -f "$HOME/.config/storage_done" ]; then
        return 0
    fi

    echo -e "\033[0;32m[*] Configurando entorno ShellAI...\033[0m"
    echo "=============================================="
    
    echo "🔹 Paso 1/5: Dependencias de Termux..."
    pkg update -y --quiet >/dev/null 2>&1
    pkg install -y --quiet proot-distro git curl wget nano vim jq tar gzip openssl termux-api >/dev/null 2>&1
    echo "✅ Paso 1/5 completado."

    echo "🔹 Paso 2/5: Instalando Debian..."
    if ! proot-distro list | grep -q '^debian'; then
        proot-distro install debian --quiet >/dev/null 2>&1
    fi
    echo "✅ Paso 2/5 completado."

    echo "🔹 Paso 3/5: OpenSCAD, FreeCAD y herramientas..."
    proot-distro login debian -- bash -c "
        apt update --quiet >/dev/null 2>&1 &&
        apt upgrade -y --quiet >/dev/null 2>&1 &&
        apt install -y --quiet --no-install-recommends openscad freecad freecad-common freecad-python3 \\
                      iproute2 net-tools traceroute mtr whois dnsutils tcpdump nmap \\
                      python3 python3-pip" >/dev/null 2>&1
    echo "✅ Paso 3/5 completado."

    echo "🔹 Paso 4/5: Acceso al almacenamiento..."
    if [ ! -f "$HOME/.config/storage_done" ]; then
        termux-setup-storage >/dev/null 2>&1
        mkdir -p "$HOME/.config"
        touch "$HOME/.config/storage_done"
    fi
    echo "✅ Paso 4/5 completado."

    echo "🔹 Paso 5/5: Estructura de directorios..."
    mkdir -p "$HOME/docs" "$HOME/.shortcuts/restore_temp" "$HOME/docs/templates"
    echo -e "\033[0;32m[✓] Entorno listo.\033[0m"
}

# ===================== GENERAR G-CODE =====================
generate_gcode() {
    clear
    echo "🖨️  Generador de G-code para BambuLab A1 Mini (PETG)"
    echo "=================================================="

    DOWNLOAD_DIR="$HOME/storage/shared/Download"
    GCODE_DIR="$DOWNLOAD_DIR/gcode"
    LOG_FILE="$HOME/prusa_debug.log"
    mkdir -p "$GCODE_DIR"

    if [ ! -d "$DOWNLOAD_DIR" ]; then
        echo "❌ Acceso a Download no disponible. Ejecuta termux-setup-storage."
        read -p "Presiona ENTER para continuar..." _
        return
    fi

    # Instalar prusa-slicer si no está
    if ! proot-distro login debian -- command -v prusa-slicer >/dev/null 2>&1; then
        echo "⚠️  Instalando PrusaSlicer en Debian..."
        proot-distro login debian -- bash -c "
            apt update --quiet >/dev/null 2>&1 &&
            apt install -y --quiet --no-install-recommends prusa-slicer" >/dev/null 2>&1
        if ! proot-distro login debian -- command -v prusa-slicer >/dev/null 2>&1; then
            echo "❌ Error al instalar PrusaSlicer."
            read -p "Presiona ENTER para continuar..." _
            return
        fi
        echo "✅ PrusaSlicer instalado."
        sleep 1
    fi

    # Crear perfil dentro de Debian
    proot-distro login debian -- bash -c '
        mkdir -p ~/.config
        cat > ~/.config/bambulab_a1_mini_petg.ini <<EOF
bed_shape = -90x-90,90x-90,90x90,-90x90
bed_temperature = 80
nozzle_diameter = 0.4
filament_diameter = 1.75
temperature = 230
first_layer_temperature = 230
first_layer_bed_temperature = 80
layer_height = 0.2
infill_density = 20%
perimeter_speed = 60
infill_speed = 80
travel_speed = 120
use_relative_e_distances = 1
gcode_flavor = marlin
layer_gcode = G92 E0
EOF
    '

    # Buscar STLs
    mapfile -d '' stl_files < <(find "$DOWNLOAD_DIR" -maxdepth 1 -name "*.stl" -print0 2>/dev/null)
    if [ ${#stl_files[@]} -eq 0 ] || [ ! -e "${stl_files[0]}" ]; then
        echo "⚠️  No hay archivos .stl en: $DOWNLOAD_DIR"
        read -p "Presiona ENTER para continuar..." _
        return
    fi

    echo "Selecciona un archivo STL:"
    for i in "${!stl_files[@]}"; do
        echo "  $((i+1))) $(basename "${stl_files[$i]}")"
    done
    echo
    read -rp "Número: " sel
    if ! [[ "$sel" =~ ^[0-9]+$ ]] || [ "$sel" -le 0 ] || [ "$sel" -gt "${#stl_files[@]}" ]; then
        echo "❌ Selección inválida."
        read -p "Presiona ENTER para continuar..." _
        return
    fi

    selected="${stl_files[$((sel-1))]}"
    base=$(basename "$selected" .stl)
    output="$GCODE_DIR/${base}_a1mini_petg.gcode"

    # Rutas dentro de Debian
    stl_in_debian="/sdcard/Download/$(basename "$selected")"
    gcode_out_debian="/sdcard/Download/gcode/${base}_a1mini_petg.gcode"

    echo
    echo "Procesando: $(basename "$selected")"
    echo "Salida: $output"
    echo "Guardando log en: $LOG_FILE"
    echo

    # Ejecutar SIN --center (¡era el error!)
    proot-distro login debian -- timeout 120s prusa-slicer \
        --load ~/.config/bambulab_a1_mini_petg.ini \
        --export-gcode \
        --output "$gcode_out_debian" \
        "$stl_in_debian" 2>&1 | tee "$LOG_FILE"

    echo
    echo "=== LOG DE PRUSASLICER ==="
    cat "$LOG_FILE"
    echo "==========================="
    echo

    if [ -f "$output" ] && [ -s "$output" ]; then
        echo "✅ G-code generado con éxito."
        echo "Ubicación: $output"
    else
        echo "❌ ERROR: No se generó el G-code."
        echo "Revisa el log anterior para diagnosticar."
    fi
    read -p "Presiona ENTER para continuar..." _
}

# ===================== MENÚ PRINCIPAL =====================
initialize_environment

while :; do
    clear
    echo "===== 🐚 SHELLAI.SH ====="
    echo "1) IA 3D"
    echo "2) Usar Gemini CLI"
    echo "3) Backup COMPLETO del Proyecto a GitHub"
    echo "4) Iniciar shell Debian"
    echo "5) Utilidades Networking"
    echo "6) 🖨️  Generar G-code (BambuLab A1 Mini + PETG)"
    echo "7) Salir"
    echo "=========================="
    read -rp "Elige opción: " opt
    case $opt in
        1) "$SCRIPT_DIR/modules/ia_3d.sh" ;;
        2) "$SCRIPT_DIR/modules/gemini_cli.sh" ;;
        3) "$SCRIPT_DIR/modules/upload_script.sh" ;;
        4) "$SCRIPT_DIR/modules/debian_shell.sh" ;;
        5) "$SCRIPT_DIR/modules/networking.sh" ;;
        6) generate_gcode ;;
        7) exit ;;
        *) echo "Opción inválida"; sleep 1 ;;
    esac
done
