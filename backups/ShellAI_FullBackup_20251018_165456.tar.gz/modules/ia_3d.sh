#!/data/data/com.termux/files/usr/bin/bash
# modules/ia_3d.sh - Módulo de diseño 3D con OpenSCAD (guarda en Download de Android)

clear
echo "===== 🛠️  IA 3D - Diseño Paramétrico ====="
echo "1) OpenSCAD (modelado programático)"
echo "2) FreeCAD (modelado CAD)"
echo "3) Volver"
read -rp "Elige opción: " opt

case $opt in
    1)
        clear
        echo "=== 📐 OpenSCAD ==="
        echo "Introduce el nombre de tu proyecto (sin extensión):"
        read -rp "Nombre: " project_name

        if [ -z "$project_name" ]; then
            project_name="proyecto"
            echo "⚠️  Nombre vacío. Usando '$project_name' por defecto."
        fi

        # Ruta en la carpeta Download de Android
        DOWNLOAD_DIR="$HOME/storage/shared/Download"
        SCAD_FILE="$DOWNLOAD_DIR/${project_name}.scad"
        STL_FILE="$DOWNLOAD_DIR/${project_name}.stl"

        # Verificar acceso a Download
        if [ ! -d "$DOWNLOAD_DIR" ]; then
            echo "❌ No se detecta acceso a la carpeta Download."
            echo "Ejecuta 'termux-setup-storage' y concede el permiso."
            read -p "Presiona ENTER para continuar..." _
            return
        fi

        # Crear archivo .scad básico
        cat > "$SCAD_FILE" <<EOF
// Proyecto: $project_name
// Generado por ShellAI

// Ejemplo: cubo de 20x20x10 mm
cube([20, 20, 10], center=true);
EOF

        echo
        echo "✅ Archivo creado: $SCAD_FILE"
        echo "Abriendo editor (nano) para que lo modifiques..."
        echo "➡️  Guarda con Ctrl+O → Enter, y sal con Ctrl+X."
        echo
        sleep 2

        # Abrir con nano
        nano "$SCAD_FILE"

        # Preguntar si generar STL
        echo
        read -p "¿Quieres generar el archivo STL ahora? (s/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Ss]$ ]]; then
            echo "Generando modelo 3D con OpenSCAD en Debian..."
            proot-distro login debian -- openscad -o "$STL_FILE" "$SCAD_FILE" >/dev/null 2>&1
            if [ -f "$STL_FILE" ]; then
                echo "✅ STL generado con éxito: $STL_FILE"
                echo "Ubicación en Android: Carpeta Download → $project_name.stl"
            else
                echo "❌ Error: No se pudo generar el STL. ¿El código SCAD es válido?"
            fi
        else
            echo "Puedes generar el STL más tarde desde la opción 6 (PrusaSlicer)."
        fi
        read -p "Presiona ENTER para continuar..." _
        ;;
    2)
        echo "FreeCAD aún en desarrollo..."
        sleep 2
        ;;
    *)
        ;;
esac
