#!/data/data/com.termux/files/usr/bin/bash
# config.sh - Configuración global y funciones de inicialización

# --- Variables de Configuración ---
export HOME_DOCS="$HOME/docs"
export DL="$HOME/storage/downloads"
export SHORTCUTS_DIR="$HOME/.shortcuts"
export PROOT_DIR="/data/data/com.termux/files/usr/var/lib/proot-distro/installed-rootfs/debian"
export DOCS_DIR="$HOME/storage/shared/Documents"
export BACKUP_FILE="$DOCS_DIR/backup_latest.tar.gz"
export ENCRYPTED_BACKUP="$DOCS_DIR/backup_latest.enc"
export CONF_FILE="$HOME/.config/shell_conf"
export TEMPLATES_DIR="$HOME_DOCS/templates"
export OWNER="txurtxil"
export REPO="ia"

# --- Funciones de Inicialización ---
load_or_prompt_credentials() {
    if [ -f "$CONF_FILE" ]; then
        source "$CONF_FILE"
    fi

    if [ -z "$TOKEN" ] || [ -z "$PASS" ] || [ -z "$GEMINI_KEY" ]; then
        echo "¡Configuración inicial necesaria!"
        [ -z "$TOKEN" ] && read -rp "Introduce TOKEN de GitHub: " TOKEN
        [ -z "$PASS" ] && read -srp "Introduce contraseña de backup: " PASS
        [ -z "$GEMINI_KEY" ] && read -srp "Introduce tu clave de la API de Gemini: " GEMINI_KEY
        echo
        echo "TOKEN=\"$TOKEN\"" > "$CONF_FILE"
        echo "PASS=\"$PASS\"" >> "$CONF_FILE"
        echo "GEMINI_KEY=\"$GEMINI_KEY\"" >> "$CONF_FILE"
        chmod 600 "$CONF_FILE"
        echo "Configuración guardada en $CONF_FILE."
        read -n1 -s -r -p "Pulsa cualquier tecla para continuar..."
    fi
    export TOKEN PASS GEMINI_KEY
}

# --- PLANTILLAS AVANZADAS ---
create_default_templates() {
    # ========== PLANTILLAS OPENSCAD ==========

    # Plantilla: Caja Básica
    cat > "$TEMPLATES_DIR/caja_basica_openscad.scad.prompt" << 'EOF'
Crea una caja rectangular en OpenSCAD con las siguientes dimensiones:
- Ancho: [ancho] mm.
- Profundidad: [profundidad] mm.
- Altura: [altura] mm.
- Grosor de las paredes: [grosor] mm.
- La tapa debe ser separable y encajar perfectamente.
- Solo devuelve el código OpenSCAD, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Engranaje
    cat > "$TEMPLATES_DIR/engranaje_openscad.scad.prompt" << 'EOF'
Crea un engranaje de [numero_dientes] dientes en OpenSCAD.
- Diámetro exterior: [diametro_exterior] mm.
- Grosor del engranaje: [grosor] mm.
- Diámetro del agujero central: [diametro_agujero] mm.
- Asegúrate de que el engranaje sea simétrico y que los dientes estén correctamente espaciados.
- Solo devuelve el código OpenSCAD, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Caja con Bisagras y Cierre Magnético
    cat > "$TEMPLATES_DIR/caja_bisagras_magnetica_openscad.scad.prompt" << 'EOF'
Crea una caja rectangular con tapa abatible en OpenSCAD. La tapa debe estar unida al cuerpo mediante dos bisagras cilíndricas integradas. Además, debe tener un cierre magnético en el frente.

Parámetros:
- Ancho exterior de la caja: [ancho] mm.
- Profundidad exterior: [profundidad] mm.
- Altura exterior total (cuerpo + tapa): [altura_total] mm.
- Grosor de las paredes: [grosor] mm.
- Diámetro del imán de cierre: [diametro_iman] mm.
- Espesor del imán: [espesor_iman] mm.
- Diámetro del pasador de la bisagra: [diametro_bisagra] mm.
- Longitud del pasador de bisagra: [longitud_bisagra] mm.

Instrucciones:
1. El cuerpo de la caja debe tener un rebaje interno para alojar el imán.
2. La tapa debe tener un rebaje interno complementario para el otro imán.
3. Las bisagras deben ser cilindros huecos en el cuerpo y cilindros sólidos en la tapa que encajen perfectamente.
4. Asegúrate de que la tapa pueda girar libremente alrededor del eje de las bisagras.
5. Solo devuelve el código OpenSCAD, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Soporte para Teléfono
    cat > "$TEMPLATES_DIR/soporte_telefono_openscad.scad.prompt" << 'EOF'
Diseña un soporte para teléfono en OpenSCAD con un ángulo de inclinación ajustable y una ranura en la base para pasar el cable de carga.

Parámetros:
- Ancho del teléfono: [ancho_telefono] mm.
- Grosor del teléfono: [grosor_telefono] mm.
- Ángulo de inclinación deseado: [angulo] grados.
- Altura máxima del soporte (desde la mesa hasta la parte superior donde apoya el teléfono): [altura_max] mm.
- Ancho de la ranura para el cable: [ancho_ranura] mm.
- Profundidad de la ranura para el cable: [profundidad_ranura] mm.
- Grosor del material del soporte: [grosor_material] mm.

Instrucciones:
1. El soporte debe tener una "V" invertida como estructura principal.
2. La parte trasera debe ser una placa vertical que sostenga el teléfono.
3. La parte delantera debe ser una placa inclinada que forme el ángulo especificado.
4. La base debe tener una ranura centrada para el cable.
5. Asegúrate de que el teléfono quede estable y no se caiga.
6. Solo devuelve el código OpenSCAD, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Engranaje Helicoidal
    cat > "$TEMPLATES_DIR/engranaje_helicoidal_openscad.scad.prompt" << 'EOF'
Genera un engranaje helicoidal en OpenSCAD. Este tipo de engranaje tiene dientes que siguen una hélice, lo que permite una transmisión más suave.

Parámetros:
- Número de dientes: [numero_dientes].
- Módulo: [modulo] mm. (Define el tamaño del diente).
- Ángulo de presión: [angulo_presion] grados (típico 20°).
- Ángulo de hélice: [angulo_helice] grados.
- Ancho de cara (grosor del engranaje): [ancho_cara] mm.
- Diámetro del agujero central: [diametro_agujero] mm.

Instrucciones:
1. Calcula el diámetro primitivo: Dp = módulo * número_de_dientes.
2. Usa una aproximación para crear la forma helicoidal del diente (puedes usar `linear_extrude` con torsión).
3. Asegúrate de que los dientes estén correctamente espaciados y que el agujero central sea concéntrico.
4. El resultado debe ser un sólido válido para impresión 3D.
5. Solo devuelve el código OpenSCAD, sin comentarios ni explicaciones adicionales.
EOF

    # ========== PLANTILLAS FREECAD ==========

    # Plantilla: Soporte en L
    cat > "$TEMPLATES_DIR/soporte_L_freecad.py.prompt" << 'EOF'
Crea un soporte en forma de L en FreeCAD usando Python.
- La base debe medir [largo_base] mm de largo y [ancho_base] mm de ancho.
- La altura vertical debe ser [altura] mm.
- El grosor del material debe ser [grosor] mm.
- El soporte debe tener agujeros de [diametro_agujeros] mm de diámetro en las esquinas para tornillos.
- Guarda el resultado como un archivo STL en la ruta: /data/data/com.termux/files/home/storage/downloads/modelo.stl
- Solo devuelve el código Python, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Caja Básica
    cat > "$TEMPLATES_DIR/caja_basica_freecad.py.prompt" << 'EOF'
Crea una caja rectangular sólida en FreeCAD usando Python.
- Ancho: [ancho] mm.
- Profundidad: [profundidad] mm.
- Altura: [altura] mm.
- La caja debe ser un único objeto sólido.
- Guarda el resultado como un archivo STL en la ruta: /data/data/com.termux/files/home/storage/downloads/modelo.stl
- Solo devuelve el código Python, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Tuerca y Perno
    cat > "$TEMPLATES_DIR/tuerca_perno_freecad.py.prompt" << 'EOF'
Crea un script de Python para FreeCAD que genere un perno hexagonal y su tuerca correspondiente. La rosca debe ser aproximada con una hélice y una sección triangular.

Parámetros para el Perno:
- Diámetro del vástago: [diametro_vastago] mm.
- Longitud del vástago: [longitud_vastago] mm.
- Paso de la rosca: [paso_rosca] mm.
- Diámetro de la cabeza hexagonal (distancia entre caras opuestas): [diametro_cabeza] mm.
- Altura de la cabeza: [altura_cabeza] mm.

Parámetros para la Tuerca:
- Diámetro exterior hexagonal (distancia entre caras opuestas): [diametro_tuerca] mm.
- Altura de la tuerca: [altura_tuerca] mm.
- Diámetro del agujero interno: [diametro_agujero_tuerca] mm (debe coincidir con el diámetro del vástago).

Instrucciones:
1. Para el perno:
   a. Crea un cilindro para el vástago.
   b. Crea un prisma hexagonal para la cabeza.
   c. Crea una hélice con el paso especificado.
   d. Crea un triángulo (sección de la rosca) y extrúyelo a lo largo de la hélice para crear la rosca.
   e. Fusiona la rosca con el vástago.
   f. Fusiona el vástago con la cabeza.
2. Para la tuerca:
   a. Crea un prisma hexagonal.
   b. Crea un cilindro para el agujero interno y réstalo del hexágono.
   c. (Opcional) Intenta crear una rosca interna usando una hélice y una operación de corte, pero si es demasiado complejo, omítelo.
3. Guarda el perno como "/data/data/com.termux/files/home/storage/downloads/perno.stl".
4. Guarda la tuerca como "/data/data/com.termux/files/home/storage/downloads/tuerca.stl".
5. Solo devuelve el código Python, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Marco de Bicicleta
    cat > "$TEMPLATES_DIR/cuadro_bici_freecad.py.prompt" << 'EOF'
Crea un script de Python para FreeCAD que genere un marco básico de cuadro de bicicleta usando tubos cilíndricos.

Parámetros:
- Longitud del tubo superior (top tube): [long_top] mm.
- Longitud del tubo inferior (down tube): [long_down] mm.
- Longitud del tubo del asiento (seat tube): [long_asiento] mm.
- Ángulo del tubo del asiento: [angulo_asiento] grados.
- Ángulo del tubo de dirección (head tube): [angulo_direccion] grados.
- Diámetro de los tubos: [diametro_tubos] mm.
- Grosor de la pared de los tubos: [grosor_pared] mm.

Instrucciones:
1. Define los puntos clave del cuadro: centro del eje del pedalier, parte superior del tubo del asiento, parte superior del tubo de dirección, parte inferior del tubo de dirección.
2. Calcula las posiciones de los extremos de cada tubo en función de las longitudes y ángulos dados.
3. Crea un cilindro hueco (tubo) para cada segmento.
4. Posiciona y rota cada tubo para que sus extremos coincidan y formen las uniones.
5. Fusiona todos los tubos en un solo objeto sólido.
6. Guarda el modelo como "/data/data/com.termux/files/home/storage/downloads/cuadro_bici.stl".
7. Solo devuelve el código Python, sin comentarios ni explicaciones adicionales.
EOF

    # Plantilla: Caja de Cambios
    cat > "$TEMPLATES_DIR/caja_cambios_freecad.py.prompt" << 'EOF'
Crea un script de Python para FreeCAD que genere una caja de cambios simplificada de 2 velocidades. Debe contener 3 engranajes: uno de entrada, uno loco (intermedio) y uno de salida.

Parámetros:
- Diámetro primitivo del engranaje de entrada: [dp_entrada] mm.
- Número de dientes del engranaje de entrada: [dientes_entrada].
- Diámetro primitivo del engranaje loco: [dp_loco] mm.
- Número de dientes del engranaje loco: [dientes_loco].
- Diámetro primitivo del engranaje de salida: [dp_salida] mm.
- Número de dientes del engranaje de salida: [dientes_salida].
- Grosor de los engranajes: [grosor_engranajes] mm.
- Distancia entre centros de los ejes (entrada-loco y loco-salida): [distancia_centros] mm.

Instrucciones:
1. Crea tres cilindros para los ejes.
2. Crea tres engranajes (discos con dientes). Puedes aproximar los dientes como pequeños rectángulos o trapezoides dispuestos en un círculo.
3. Posiciona los engranajes de manera que el de entrada engrane con el loco, y el loco engrane con el de salida. La distancia entre centros debe ser exactamente la especificada.
4. Asegúrate de que los engranajes no se solapen y que haya un pequeño juego para que puedan girar.
5. Fusiona cada engranaje con su eje correspondiente.
6. Guarda el modelo como "/data/data/com.termux/files/home/storage/downloads/caja_cambios.stl".
7. Solo devuelve el código Python, sin comentarios ni explicaciones adicionales.
EOF
}

# --- Inicialización Automática ---
load_or_prompt_credentials
create_default_templates
