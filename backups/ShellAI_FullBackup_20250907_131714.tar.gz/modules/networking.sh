#!/data/data/com.termux/files/usr/bin/bash
# modules/networking.sh - Módulo de utilidades de networking

# Importar configuración
source "$(dirname "$0")/../config.sh"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'
PROOT_CMD="proot-distro login debian -- /bin/bash -c"
TERMUX_CMD="/data/data/com.termux/files/usr/bin/bash -c"

show_banner() {
    echo -e "${GREEN}"
    echo "================================================"
    echo "   Analizador de Red con Debian (Proot) v2.0    "
    echo "================================================"
    echo -e "${NC}"
}

check_dependencies() {
    echo -e "\n${YELLOW}--- Verificando Dependencias ---${NC}"
    local termux_deps=("iproute2" "net-tools" "curl")
    local debian_deps=("iproute2" "net-tools" "traceroute" "mtr" "whois" "dnsutils" "tcpdump" "nmap")
    local missing_termux=()
    local missing_debian=()

    for dep in "${termux_deps[@]}"; do
        if ! $TERMUX_CMD "command -v $dep &> /dev/null"; then
            missing_termux+=("$dep")
        fi
    done

    for dep in "${debian_deps[@]}"; do
        if ! $PROOT_CMD "command -v $dep &> /dev/null"; then
            missing_debian+=("$dep")
        fi
    done

    if [ ${#missing_termux[@]} -gt 0 ]; then
        echo -e "${RED}Faltan herramientas en Termux:${NC} ${missing_termux[*]}"
        echo -e "${YELLOW}Para instalarlas, ejecuta: ${NC}pkg install ${missing_termux[*]}"
    else
        echo -e "${GREEN}Todas las dependencias de Termux están instaladas.${NC}"
    fi

    if [ ${#missing_debian[@]} -gt 0 ]; then
        echo -e "${RED}Faltan herramientas en el contenedor Debian:${NC} ${missing_debian[*]}"
        echo -e "${YELLOW}Para instalarlas, ejecuta: ${NC}${PROOT_CMD} 'apt-get update && apt-get install -y ${missing_debian[*]}'"
    else
        echo -e "${GREEN}Todas las dependencias de Debian están instaladas.${NC}"
    fi

    echo -e "\n${GREEN}Presiona Enter para volver al menú...${NC}"
    read
}

get_ips() {
    echo -e "${YELLOW}--- Tus Direcciones IP (vistas desde Termux) ---${NC}"
    echo -n "IP Local del Dispositivo: "
    if $TERMUX_CMD "command -v ip &> /dev/null"; then
        $TERMUX_CMD "ip a | grep 'inet ' | grep -v '127.0.0.1' | awk '{print \$2}' | cut -d/ -f1"
    elif $TERMUX_CMD "command -v ifconfig &> /dev/null"; then
        $TERMUX_CMD "ifconfig | grep 'inet ' | grep -v '127.0.0.1' | awk '{print \$2}' | cut -d/ -f1"
    else
        echo -e "${RED}Error: Herramienta 'ip' o 'ifconfig' no encontrada en Termux.${NC}"
        echo -e "${YELLOW}Ejecuta 'opción 7' para instalar las dependencias faltantes.${NC}"
    fi

    echo -n "IP Pública (puede tardar): "
    if $TERMUX_CMD "command -v curl &> /dev/null"; then
        $TERMUX_CMD "curl -s ifconfig.me"
    else
        echo -e "${RED}Error: Herramienta 'curl' no encontrada en Termux.${NC}"
        echo -e "${YELLOW}Ejecuta 'opción 7' para instalar las dependencias faltantes.${NC}"
    fi
    echo ""
}

show_connections() {
    echo -e "\n${YELLOW}--- Conexiones de Red Activas (desde Termux) ---${NC}"
    if $TERMUX_CMD "command -v ss &> /dev/null"; then
        $TERMUX_CMD "ss -tulnp"
    elif $TERMUX_CMD "command -v netstat &> /dev/null"; then
        $TERMUX_CMD "netstat -tulnp"
    else
        echo -e "${RED}Error: Herramienta 'ss' o 'netstat' no encontrada en Termux.${NC}"
        echo -e "${YELLOW}Ejecuta 'opción 7' para instalar las dependencias faltantes.${NC}"
    fi
}

trace_route() {
    read -p "Introduce el dominio o IP para Traceroute (ej: 1.1.1.1): " target
    if [[ ! -z "$target" ]]; then
        echo -e "\n${YELLOW}--- Trazando la ruta a $target ---${NC}"
        ${PROOT_CMD} "traceroute $target"
    else
        echo -e "${RED}No se introdujo un destino.${NC}"
    fi
}

mtr_route() {
    read -p "Introduce el dominio o IP para MTR (ej: google.com): " target
    if [[ ! -z "$target" ]]; then
        echo -e "\n${YELLOW}--- Ejecutando MTR hacia $target ---${NC}"
        ${PROOT_CMD} "mtr -r -c 10 $target"
    else
        echo -e "${RED}No se introdujo un destino.${NC}"
    fi
}

capture_packets() {
    echo -e "\n${YELLOW}--- Captura de Paquetes con tcpdump ---${NC}"
    echo -e "${RED}AVISO: Debido a las limitaciones de proot, es probable que solo veas el tráfico generado DENTRO de Debian.${NC}"
    read -p "Introduce la interfaz de red (ej: eth0, any) o deja en blanco para 'any': " interface
    interface=${interface:-any}
    read -p "Introduce un filtro (ej: 'port 80' o 'host 1.1.1.1') o deja en blanco: " filter
    echo -e "\n${YELLOW}Iniciando tcpdump... (Presiona Ctrl+C para detener la captura)${NC}"
    ${PROOT_CMD} "tcpdump -i ${interface} -n ${filter}"
}

get_domain_info() {
    read -p "Introduce el dominio o IP a consultar (ej: wikipedia.org): " target
    if [[ ! -z "$target" ]]; then
        echo -e "\n${YELLOW}--- Información WHOIS de $target ---${NC}"
        ${PROOT_CMD} "whois $target"
        echo -e "\n${YELLOW}--- Registros DNS (A, AAAA, MX) de $target ---${NC}"
        ${PROOT_CMD} "dig $target A +short; dig $target AAAA +short; dig $target MX +short"
    else
        echo -e "${RED}No se introdujo un destino.${NC}"
    fi
}

scan_ports() {
    read -p "Introduce la IP objetivo para escanear (ej: 192.168.1.1): " target_ip
    if [[ -z "$target_ip" ]]; then
        echo -e "${RED}No se introdujo una IP válida.${NC}"
        return
    fi
    echo -e "\n${YELLOW}--- Escaneando puertos en $target_ip ---${NC}"
    ${PROOT_CMD} "nmap -sV -T4 $target_ip"
}

monitor_bandwidth() {
    echo -e "\n${YELLOW}--- Monitor de Ancho de Banda en Tiempo Real ---${NC}"
    echo "Presiona Ctrl+C para detener."
    echo ""
    interface=$(awk '/:/ && !/lo/ {print $1}' /proc/net/dev | sed 's/:.*$//' | head -n 1)
    if [ -z "$interface" ]; then
        echo -e "${RED}No se pudo determinar la interfaz de red activa.${NC}"
        return
    fi
    echo "Interfaz: $interface"
    echo "--------------------------------------------------"
    printf "%-10s %-15s %-15s\n" "Tiempo" "Recibido (KB/s)" "Enviado (KB/s)"

    get_bytes() {
        awk -v iface="$interface" '$0 ~ iface ":" {
            gsub(/:/, "", $1);
            print $2, $10
        }' /proc/net/dev
    }

    read rx_prev tx_prev < <(get_bytes)

    while true; do
        sleep 1
        read rx_now tx_now < <(get_bytes)
        rx_diff=$((rx_now - rx_prev))
        tx_diff=$((tx_now - tx_prev))
        rx_kb=$((rx_diff / 1024))
        tx_kb=$((tx_diff / 1024))
        printf "%-10s %-15s %-15s\n" "$(date +%H:%M:%S)" "$rx_kb" "$tx_kb"
        rx_prev=$rx_now
        tx_prev=$tx_now
    done
}

networking_utilities_menu() {
    while true; do
        clear
        show_banner
        get_ips
        echo -e "\nElige una herramienta de análisis:"
        echo "1. Ver conexiones activas (netstat)"
        echo "2. Traceroute clásico"
        echo -e "3. ${GREEN}MTR (Traceroute + Ping avanzado)${NC}"
        echo "4. Obtener información de Dominio/IP (Whois & DNS)"
        echo -e "5. ${RED}Capturar paquetes (tcpdump)${NC}"
        echo "6. Escanear puertos (nmap)"
        echo "7. Monitor de ancho de banda"
        echo "8. Volver"
        echo -e "9. ${YELLOW}Verificar e Instalar Dependencias${NC}"
        read -p "Opción: " choice
        case $choice in
            1) show_connections ;;
            2) trace_route ;;
            3) mtr_route ;;
            4) get_domain_info ;;
            5) capture_packets ;;
            6) scan_ports ;;
            7) monitor_bandwidth ;;
            8) break ;;
            9) check_dependencies ;;
            *) echo -e "${RED}Opción no válida.${NC}" ;;
        esac
        [ "$choice" -ne 8 ] && echo -e "\n${GREEN}Presiona Enter para volver al menú...${NC}" && read
    done
}

networking_utilities_menu
