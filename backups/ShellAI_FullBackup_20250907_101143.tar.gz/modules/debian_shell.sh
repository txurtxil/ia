#!/data/data/com.termux/files/usr/bin/bash
# modules/debian_shell.sh - Módulo para iniciar la shell de Debian

# Importar configuración
source "$(dirname "$0")/../config.sh"

# --- FUNCIONES ---
debian_shell() {
    proot-distro login debian
}

# Ejecutar la función
debian_shell
