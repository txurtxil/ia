#!/data/data/com.termux/files/usr/bin/bash
# modules/networking.sh - Módulo de utilidades de networking

# Importar configuración
source "$(dirname "$0")/../config.sh"

# --- Estilos y Comandos para Networking ---
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # Sin Color
PROOT_CMD="proot-distro login debian -- /bin/bash -c"
TERMUX_CMD="/data/data/com.termux/files/usr/bin/bash -c"

# --- Funciones de Networking ---
# ... (Copiar aquí todas las funciones: show_banner, check_dependencies, get_ips, show_connections, trace_route, mtr_route, capture_packets, get_domain_info, scan_ports, monitor_bandwidth, networking_utilities_menu)

# --- Ejecutar el menú de networking ---
networking_utilities_menu
