#!/data/data/com.termux/files/usr/bin/bash
# modules/entorno.sh - Módulo de instalación/restauración de entorno

# Importar configuración
source "$(dirname "$0")/../config.sh"

# --- FUNCIONES DE GEMINI CLI ---
backup() {
    dpkg --get-selections > "$DOCS_DIR/packages.list"
    tar --ignore-failed-read -czf "$BACKUP_FILE" \
        "$SHORTCUTS_DIR/menu.sh" \
        "$HOME_DOCS" \
        "$PROOT_DIR" \
        "$DOCS_DIR/packages.list"
    openssl enc -aes-256-cbc -pbkdf2 -salt -in "$BACKUP_FILE" -out "$ENCRYPTED_BACKUP" -k "$PASS"
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

restore() {
    termux-setup-storage
    openssl enc -d -aes-256-cbc -pbkdf2 -in "$ENCRYPTED_BACKUP" -out "$BACKUP_FILE" -k "$PASS"
    mkdir -p "$SHORTCUTS_DIR/restore_temp"
    tar xzf "$BACKUP_FILE" -C "$SHORTCUTS_DIR/restore_temp"
    cp -r "$SHORTCUTS_DIR/restore_temp/$(basename $SHORTCUTS_DIR)" "$HOME/" 2>/dev/null
    cp -r "$SHORTCUTS_DIR/restore_temp/docs" "$HOME/" 2>/dev/null
    cp -r "$SHORTCUTS_DIR/restore_temp/$(basename $PROOT_DIR)" "/data/data/com.termux/files/usr/var/lib/proot-distro/installed-rootfs/" 2>/dev/null
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

instalacion_limpia() {
    pkg update -y
    pkg install -y proot-distro
    if ! proot-distro list | grep -q '^debian'; then
        proot-distro install debian
    fi
    proot-distro login debian -- bash -c "apt update && apt upgrade -y && apt install -y openscad freecad"
    termux-setup-storage
    read -n1 -s -r -p "Pulsa cualquier tecla..."
}

# --- MENÚ ENTORNO ---
while :; do
    clear
    echo "===== INSTALAR/RESTAURAR ENTORNO ====="
    echo "1) Crear backup en Documentos"
    echo "2) Restaurar backup desde Documentos"
    echo "3) Instalación limpia (proot + Debian + OpenSCAD + FreeCAD)"
    echo "0) Volver"
    echo "============================="
    read -rp "Elige opción: " subopt
    case $subopt in
        1) backup ;;
        2) restore ;;
        3) instalacion_limpia ;;
        0) break ;;
        *) echo "Opción inválida"; sleep 1 ;;
    esac
done
