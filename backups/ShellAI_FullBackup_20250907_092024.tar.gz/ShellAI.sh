#!/data/data/com.termux/files/usr/bin/bash
# ShellAI.sh - Script principal (lanzador/orquestador)

# ===================== CONFIGURACIÓN =====================
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# --- Función de Inicialización Automática ---
initialize_environment() {
    echo -e "\033[0;32m[*] Verificando e instalando entorno...\033[0m"

    # Paso 1: Instalar dependencias básicas de Termux
    if ! command -v proot-distro &> /dev/null || ! command -v jq &> /dev/null; then
        echo "[*] Instalando dependencias de Termux..."
        pkg update -y
        pkg install -y proot-distro git curl wget nano vim jq tar gzip openssl termux-api
    fi

    # Paso 2: Instalar y configurar Debian con herramientas 3D y de red
    if ! proot-distro list | grep -q '^debian'; then
        echo "[*] Instalando distribución Debian..."
        proot-distro install debian
    fi

    # Verificar e instalar OpenSCAD y FreeCAD
    if ! proot-distro login debian -- command -v openscad &> /dev/null; then
        echo "[*] Instalando OpenSCAD, FreeCAD y herramientas de red en Debian..."
        proot-distro login debian -- bash -c "
            apt update && apt upgrade -y &&
            apt install -y openscad freecad freecad-common freecad-python3 \\
                          iproute2 net-tools traceroute mtr whois dnsutils tcpdump nmap \\
                          python3 python3-pip"
    fi

    # Paso 3: Solicitar acceso al almacenamiento
    STORAGE_FLAG="$HOME/.config/storage_done"
    if [ ! -f "$STORAGE_FLAG" ]; then
        echo "[*] Habilitando acceso al almacenamiento compartido..."
        termux-setup-storage
        mkdir -p "$HOME/.config"
        touch "$STORAGE_FLAG"
    fi

    # Paso 4: Crear directorios del proyecto
    mkdir -p "$HOME/docs"
    mkdir -p "$HOME/.shortcuts/restore_temp"
    mkdir -p "$HOME/docs/templates"

    echo -e "\033[0;32m[✓] Entorno configurado correctamente.\033[0m"
}

# Ejecutar inicialización
initialize_environment

# ===================== MENÚ PRINCIPAL =====================
while :; do
    clear
    echo "===== SHELLAI.SH ====="
    echo "1) IA 3D"
    echo "2) Usar Gemini CLI"
    echo "3) Backup COMPLETO del Proyecto a GitHub"
    echo "4) Iniciar shell Debian"
    echo "5) Utilidades Networking"
    echo "6) Salir"
    echo "=========================="
    read -rp "Elige opción: " opt
    case $opt in
        1) "$SCRIPT_DIR/modules/ia_3d.sh" ;;
        2) "$SCRIPT_DIR/modules/gemini_cli.sh" ;;
        3) "$SCRIPT_DIR/modules/upload_script.sh" ;;
        4) "$SCRIPT_DIR/modules/debian_shell.sh" ;;
        5) "$SCRIPT_DIR/modules/networking.sh" ;;
        6) exit ;;
        *) echo "Opción inválida"; sleep 1 ;;
    esac
done
